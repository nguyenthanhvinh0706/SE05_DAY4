from django.apps import AppConfig


class TrangchuConfig(AppConfig):
    name = 'TrangChu'
